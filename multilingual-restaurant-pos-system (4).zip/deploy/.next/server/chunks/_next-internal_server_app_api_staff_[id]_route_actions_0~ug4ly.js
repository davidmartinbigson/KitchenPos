module.exports=[60470,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_staff_%5Bid%5D_route_actions_0~ug4ly.js.map
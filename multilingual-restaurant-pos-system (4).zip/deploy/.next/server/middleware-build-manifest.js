globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/JpJeKa7MvIwusXWU-B--k/_buildManifest.js",
    "static/JpJeKa7MvIwusXWU-B--k/_ssgManifest.js",
    "static/JpJeKa7MvIwusXWU-B--k/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/15pjn.n4_q6le.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0q_8.tqs5n-zm.js",
    "static/chunks/0c7h~x4_chf35.js",
    "static/chunks/turbopack-0azzthvclwk11.js"
  ]
};
